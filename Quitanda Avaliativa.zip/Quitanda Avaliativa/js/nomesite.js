const nomeSite = document.querySelector('#name');
nomeSite.textContent = 'Site Avaliativo';

const titulo = document.querySelector('#title');
titulo.textContent = 'Atividade CSS e Bootstrap';

const noty = document.querySelector('#carrinho');
noty.textContent = '9';